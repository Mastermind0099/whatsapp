//RapipppGnzz
//not sale this script

require("./all/module")
//GLOBAL PAYMENT
global.storename = "crack by aries"
global.dana = "nolu"
global.qris = "-"
// GLOBAL SETTING
global.owner = "62"
global.namabot = "bot"
global.nomorbot = "62"
global.namaCreator = "bot"
global.linkyt = "https://www.instagram.com/arissh25_"
global.autoJoin = false
global.antilink = false
global.versisc = '30'
// DELAY JPM
global.delayjpm = 5500

//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://deposit.pictures/p/8f3f4ab89de24d3faef51146d7439b3a'
global.isLink = 'https://chat.whatsapp.com/FKmeQAizNK9GfQU8bno0C'
global.packname = "Bugs"
global.author = "RIEEZ"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})